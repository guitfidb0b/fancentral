using Microsoft.EntityFrameworkCore;
using FanCentral.Models;

namespace FanCentral.Data
{
    public class FanCentralContext : DbContext
    {
        public FanCentralContext (DbContextOptions<FanCentralContext> options)
            : base(options)
        {
        }

        public DbSet<Product> Product { get; set; }
    }
}