﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using FanCentral.Models;

namespace FanCentral.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Save()
        {
            return View();
        }

        public IActionResult MyAccount()
        {
            return View();
        }

        public IActionResult TrackOrder()
        {
            return View();
        }

        public IActionResult Cart()
        {
            return View();
        }

        public IActionResult Deal()
        {
            return View();
        }
        
        public IActionResult Help()
        {
            return View();
        }

        public IActionResult SizeChart()
        {
            return View();
        }
        
        public IActionResult SafeShopping()
        {
            return View();
        }

        public IActionResult ShippingRates()
        {
            return View();
        }

        public IActionResult JerseyAssurance()
        {
            return View();
        }

        public IActionResult About()
        {
            return View();
        }

        public IActionResult ProShop()
        {
            return View();
        }

        public IActionResult JagsApparrel()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
